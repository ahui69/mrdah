# Mordzix AI Frontend

Angular 17+ frontend dla Mordzix AI cognitive assistant.

## Quick Start

### Development
```bash
npm install
npm start
# Otwórz: http://localhost:4200
```

### Production Build
```bash
npm run build:prod
# Output: dist/mordzix-ai/
```

## Architektura

```
src/
├── app/
│   ├── core/           # Serwisy (API, Auth, Memory)
│   ├── components/     # UI komponenty (Chat, Header, Sidebar)
│   └── shared/         # Współdzielone komponenty
├── environments/       # Konfiguracja (dev/prod)
├── assets/             # Statyczne pliki
└── styles.scss         # Globalne style
```

## API Integration

Backend URL konfiguruje się w `src/environments/`:

- **Development**: `http://localhost:8080`
- **Production**: `` (pusty = ten sam host)

Auth token: `ssjjMijaja6969`

## Deploy

Zobacz: `../DEPLOY_ANGULAR.md`

Lub użyj skryptu:
```powershell
# Windows
..\deploy_angular.ps1

# Linux
cd /workspace/mrd/frontend && npm run build:prod
```

## Features

- 🎨 Czysty, nowoczesny design (czarna kolorystyka)
- 💬 Real-time chat z backendem
- 🧠 Pamięć długoterminowa (use_memory: true)
- 🔄 Auto-learning (auto_learn: true)
- 📱 Responsive (mobile-friendly)
- 💾 LocalStorage (historia rozmów)
- ⚡ Lazy loading komponentów
- 🔒 Auth token bearer
- **🛠️ Panel funkcji z 20 kafelkami:**
  - 4x AI & Chat (Psyche, Memory, Proactive)
  - 3x Research (Web Search, Scraping, Deep Research)
  - 5x Creative (Image Gen/Analyze, TTS, STT, Writing)
  - 5x Tools (Files, Code Exec, Captcha, Travel, Batch)
  - 3x System (Endpoints, Admin, Metrics)

## Tech Stack

- Angular 17
- TypeScript 5.2
- RxJS 7.8
- SCSS
- HttpClient
- Standalone? NIE (NgModule)
