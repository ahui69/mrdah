import { Component, OnInit, ViewChild, ElementRef, AfterViewChecked } from '@angular/core';
import { ApiService, ChatRequest } from '../../core/services/api.service';
import { ChatService, ChatMessage } from '../../core/services/chat.service';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss']
})
export class ChatComponent implements OnInit, AfterViewChecked {
  @ViewChild('messagesContainer') messagesContainer!: ElementRef;

  messages: ChatMessage[] = [];
  messageInput = '';
  isLoading = false;
  userId = 'web_user';

  constructor(
    private apiService: ApiService,
    private chatService: ChatService
  ) {}

  ngOnInit() {
    this.chatService.messages$.subscribe(messages => {
      this.messages = messages;
    });
  }

  ngAfterViewChecked() {
    this.scrollToBottom();
  }

  sendMessage() {
    const content = this.messageInput.trim();
    if (!content || this.isLoading) return;

    // Dodaj wiadomość użytkownika
    this.chatService.addMessage('user', content);
    this.messageInput = '';

    // Dodaj placeholder dla odpowiedzi
    const assistantMsgId = this.chatService.addMessage('assistant', '', true);
    this.isLoading = true;

    // Przygotuj request
    const request: ChatRequest = {
      messages: [{ role: 'user', content }],
      user_id: this.userId,
      use_memory: true,
      auto_learn: true,
      session_id: this.chatService.getSessionId() || undefined
    };

    // Wyślij do API
    this.apiService.chat(request).subscribe({
      next: (response: any) => {
        // Aktualizuj wiadomość z odpowiedzią
        this.chatService.updateMessage(assistantMsgId, response.response || response.answer, false);
        
        // 🔥 DODAJ TOOLS DO METADATA
        if (response.metadata?.tools_used) {
          const message = this.messages.find(m => m.id === assistantMsgId);
          if (message) {
            message.toolsUsed = response.metadata.tools_used;
            message.metadata = response.metadata;
          }
        }
        
        if (response.session_id) {
          this.chatService.setSessionId(response.session_id);
        }
        this.isLoading = false;
      },
      error: (error) => {
        const errorMsg = error.error?.detail || error.message || 'Błąd komunikacji z serwerem';
        this.chatService.updateMessage(assistantMsgId, `❌ Błąd: ${errorMsg}`, false);
        this.isLoading = false;
      }
    });
  }

  onKeyPress(event: KeyboardEvent) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.sendMessage();
    }
  }

  formatToolName(toolName: string): string {
    // Formatuj nazwę tool na czytelną (web_search → Web Search)
    return toolName
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }

  private scrollToBottom() {
    try {
      const container = this.messagesContainer?.nativeElement;
      if (container) {
        container.scrollTop = container.scrollHeight;
      }
    } catch (err) {
      console.error('Scroll error:', err);
    }
  }
}
