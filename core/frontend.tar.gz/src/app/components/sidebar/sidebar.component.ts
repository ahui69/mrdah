import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {
  @Input() isOpen = false;
  @Output() close = new EventEmitter<void>();

  onClose() {
    this.close.emit();
  }

  clearChat() {
    if (confirm('Wyczyścić całą historię rozmów?')) {
      localStorage.removeItem('mordzix_chat_messages');
      localStorage.removeItem('mordzix_session_id');
      window.location.reload();
    }
  }
}
