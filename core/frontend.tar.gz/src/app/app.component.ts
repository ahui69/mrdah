import { Component, OnInit } from '@angular/core';
import { ApiService } from './core/services/api.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'Mordzix AI';
  sidebarOpen = false;
  healthStatus = 'checking...';

  constructor(private apiService: ApiService) {}

  ngOnInit() {
    this.checkHealth();
  }

  checkHealth() {
    this.apiService.health().subscribe({
      next: (res) => {
        this.healthStatus = res.status || 'ok';
      },
      error: () => {
        this.healthStatus = 'offline';
      }
    });
  }

  toggleSidebar() {
    this.sidebarOpen = !this.sidebarOpen;
  }
}
