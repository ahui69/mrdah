import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface ChatRequest {
  messages: Message[];
  user_id: string;
  use_memory?: boolean;
  auto_learn?: boolean;
  session_id?: string;
}

export interface ChatResponse {
  response: string;
  session_id?: string;
  memory_used?: boolean;
  facts_retrieved?: number;
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private apiUrl = environment.apiUrl;
  private authToken = environment.authToken;

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.authToken}`
    });
  }

  // CHAT
  chat(request: ChatRequest): Observable<ChatResponse> {
    return this.http.post<ChatResponse>(
      `${this.apiUrl}/api/chat/assistant`,
      request,
      { headers: this.getHeaders() }
    );
  }

  // PSYCHE
  getPsycheStatus(): Observable<any> {
    return this.http.get(
      `${this.apiUrl}/api/psyche/status`,
      { headers: this.getHeaders() }
    );
  }

  // MEMORY
  getMemoryStats(): Observable<any> {
    return this.http.get(
      `${this.apiUrl}/api/memory/stats`,
      { headers: this.getHeaders() }
    );
  }

  searchMemory(query: string): Observable<any> {
    return this.http.post(
      `${this.apiUrl}/api/memory/search`,
      { query },
      { headers: this.getHeaders() }
    );
  }

  // ENDPOINTS LIST
  getEndpoints(): Observable<any> {
    return this.http.get(
      `${this.apiUrl}/api/endpoints/list`,
      { headers: this.getHeaders() }
    );
  }

  // HEALTH
  health(): Observable<any> {
    return this.http.get(`${this.apiUrl}/health`);
  }
}
