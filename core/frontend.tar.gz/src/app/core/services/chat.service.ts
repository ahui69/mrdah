import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  loading?: boolean;
  toolsUsed?: string[];  // 🔥 Nowe: lista użytych tools
  metadata?: any;        // 🔥 Nowe: metadata z backendu
}

@Injectable({
  providedIn: 'root'
})
export class ChatService {
  private messagesSubject = new BehaviorSubject<ChatMessage[]>([]);
  public messages$ = this.messagesSubject.asObservable();

  private sessionId: string | null = null;

  constructor() {
    this.loadFromLocalStorage();
  }

  addMessage(role: 'user' | 'assistant' | 'system', content: string, loading = false) {
    const messages = this.messagesSubject.value;
    const newMessage: ChatMessage = {
      id: this.generateId(),
      role,
      content,
      timestamp: new Date(),
      loading
    };
    this.messagesSubject.next([...messages, newMessage]);
    this.saveToLocalStorage();
    return newMessage.id;
  }

  updateMessage(id: string, content: string, loading = false) {
    const messages = this.messagesSubject.value;
    const index = messages.findIndex(m => m.id === id);
    if (index !== -1) {
      messages[index] = { ...messages[index], content, loading };
      this.messagesSubject.next([...messages]);
      this.saveToLocalStorage();
    }
  }

  removeMessage(id: string) {
    const messages = this.messagesSubject.value.filter(m => m.id !== id);
    this.messagesSubject.next(messages);
    this.saveToLocalStorage();
  }

  clearMessages() {
    this.messagesSubject.next([]);
    this.sessionId = null;
    localStorage.removeItem('mordzix_chat_messages');
    localStorage.removeItem('mordzix_session_id');
  }

  setSessionId(id: string) {
    this.sessionId = id;
    localStorage.setItem('mordzix_session_id', id);
  }

  getSessionId(): string | null {
    return this.sessionId;
  }

  private generateId(): string {
    return `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private saveToLocalStorage() {
    const messages = this.messagesSubject.value;
    localStorage.setItem('mordzix_chat_messages', JSON.stringify(messages));
  }

  private loadFromLocalStorage() {
    const stored = localStorage.getItem('mordzix_chat_messages');
    if (stored) {
      try {
        const messages = JSON.parse(stored);
        this.messagesSubject.next(messages);
      } catch (e) {
        console.error('Failed to load messages from localStorage', e);
      }
    }

    const sessionId = localStorage.getItem('mordzix_session_id');
    if (sessionId) {
      this.sessionId = sessionId;
    }
  }
}
