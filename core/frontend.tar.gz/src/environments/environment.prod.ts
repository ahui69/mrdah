export const environment = {
  production: true,
  apiUrl: '',
  authToken: 'ssjjMijaja6969'
};
